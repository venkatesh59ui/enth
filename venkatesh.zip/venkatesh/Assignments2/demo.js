var source=[
    {
      "product_category": "kitchen",
      "product_name": "4-Piece Set Bamboo Table Matt"
    },
    {
      "product_category": "kitchen",
      "product_name": "Expresso Coffee Maker"
    },
    {
      "product_category": "shoes",
      "product_name": "Puma Trainers x3"
    },
    {
      "product_category": "home",
      "product_name": "4x6 Photo Frame"
    },
    {
      "product_category": "shoes",
      "product_name": "Skechers ProWalkers"
    },
    {
      "product_category": "home",
      "product_name": "Shower Curtain"
    },
    {
      "product_category": "home",
      "product_name": "Accent Table Lamp"
    },
    {
      "product_category": "electronics",
      "product_name": "Cannon x930 DSLR Camera"
    },
    {
      "product_category": "kitchen",
      "product_name": "12 Qt Pressure Cooker"
    },
    {
      "product_category": "electronics",
      "product_name": "Apple Iphone 8"
    },
    {
      "product_category": "kitchen",
      "product_name": "Wooden Hexagonal Coasters"
    },
    {
      "product_category": "electronics",
      "product_name": "Bose QC 300 Headphones"
    },
    {
      "product_category": "shoes",
      "product_name": "Reebok Classic 1990"
    },
    {
      "product_category": "kitchen",
      "product_name": "12-Piece Knife Set"
    },
    {
      "product_category": "shoes",
      "product_name": "Nike Air Max Elite"
    },
    {
      "product_category": "home",
      "product_name": "100% Cotton Towels"
    },
    {
      "product_category": "electronics",
      "product_name": "Sony Super Bass Earbuds"
    },
    {
      "product_category": "shoes",
      "product_name": "Addidas Foamfits"
    }
  ];
  var res={};
 
for(var i=0;i<source.length;i++){
    if(source[i].product_category in res == false){
        res[source[i].product_category]=[]; 
        res[source[i].product_category].push(source[i]);
    }else{
        res[source[i].product_category].push(source[i]);
    }
}

for(var category in res){
    var btn=document.createElement("button");
    var btnText=document.createTextNode(category);
    btn.appendChild(btnText );
    var mainEle=document.getElementById("category_list");
    mainEle.appendChild(btn);
    btn.addEventListener("click",function(event){
        document.getElementById("product_list").innerHTML='';
        var btnLabel=this.textContent;
        var products= res[btnLabel];
        for(var k=0;k<products.length;k++){
            var pro_btn=document.createElement("button");
            var pro_btnText=document.createTextNode(products[k].product_name);
            pro_btn.appendChild(pro_btnText);
            var products_container=document.getElementById("product_list");
            products_container.appendChild(pro_btn);
        }
    });
    
}